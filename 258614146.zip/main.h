// main.h
#ifndef MAIN_H
#define MAIN_H

void handleInstructions(); // Function declaration

int main(); // Function declaration

#endif // MAIN_H