// data_structures.h
#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H

#include "heap.h"
#include "stack.h"
#include "graph.h"
#include "util.h"

#endif // DATA_STRUCTURES_H
